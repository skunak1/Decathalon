package com.sprinter.competition;

import org.junit.Test;

import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

import static org.junit.Assert.*;

public class CalculatorTest {
    //TO CHECK IF RECORDS ARE POPULATED CORRECTLY FROM INPUT FILE ALONG WITH
    @Test
    public void testRecord() {
        AthleteRecord record = new AthleteRecord();
        Athlete athlete1 = new Athlete("kunal","1.5;5.2;6.7.2",61309.0);
        Athlete athlete2 = new Athlete("Lana","1.5;5.2;6.7.2",61309.0);
        Athlete athlete3 = new Athlete("Randy","1.5;5.2;6.7.3",61310.0);
        Athlete athlete4 = new Athlete("Batista","1.5;5.3;6.7.3",61311.0);
        Athlete athlete5 = new Athlete("Steve","1.0;0.1;0.0.1",102.0);
        ArrayList<Athlete> listAthlete = new ArrayList<>();
        listAthlete.add(athlete1);
        listAthlete.add(athlete2);
        listAthlete.add(athlete3);
        listAthlete.add(athlete4);
        listAthlete.add(athlete5);
        record.setAthleteList(listAthlete);
        Collections.sort(record.getAthleteList(),new SortAthlete());
        AthleteRecord realRecord = Calculator.getRecord("TestCase1.txt");
        assertEquals(record,realRecord);

    }

    @Test
    public void testPositions() {
        AthleteRecord record = new AthleteRecord();
        Athlete athlete1 = new Athlete("kunal","1.5;5.2;6.7.2","2-3",61309.0);
        Athlete athlete2 = new Athlete("Lana","1.5;5.2;6.7.2","2-3",61309.0);
        Athlete athlete3 = new Athlete("Randy","1.5;5.2;6.7.3","4-5-6",61310.0);
        Athlete athlete4 = new Athlete("Batista","1.4;5.3;6.7.3","4-5-6",61310.0);
        Athlete athlete5 = new Athlete("Steve","1.0;0.1;0.0.1","1",102.0);
        Athlete athlete6 = new Athlete("Jericho","1.5;5.2;6.7.3","4-5-6",61310.0);
        Athlete athlete7 = new Athlete("Rollins","5.6;5.3;6.7.3","7",61310.0);
        ArrayList<Athlete> listAthlete = new ArrayList<>();
        listAthlete.add(athlete1);
        listAthlete.add(athlete2);
        listAthlete.add(athlete3);
        listAthlete.add(athlete4);
        listAthlete.add(athlete5);
        record.setAthleteList(listAthlete);
        Collections.sort(record.getAthleteList(),new SortAthlete());
        AthleteRecord realRecord = Calculator.getRecord("TestCase2.txt");
        realRecord.setPosition();
        assertEquals(athlete5.getPosition(),realRecord.getAthleteList().get(0).getPosition());
        assertEquals(athlete1.getPosition(),realRecord.getAthleteList().get(1).getPosition());
        assertEquals(athlete2.getPosition(),realRecord.getAthleteList().get(2).getPosition());
        assertEquals(athlete3.getPosition(),realRecord.getAthleteList().get(3).getPosition());
        assertEquals(athlete4.getPosition(),realRecord.getAthleteList().get(4).getPosition());
        assertEquals(athlete6.getPosition(),realRecord.getAthleteList().get(5).getPosition());
        assertEquals(athlete7.getPosition(),realRecord.getAthleteList().get(6).getPosition());

    }

    @Test
    public void XMLandHTMLGenerator() {
    }
}