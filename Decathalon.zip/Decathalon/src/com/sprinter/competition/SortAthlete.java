package com.sprinter.competition;

import java.util.Comparator;

public class SortAthlete  implements Comparator<Athlete>{

	@Override
	public int compare(Athlete athlete1, Athlete athlete2) {
		if(athlete1.getTotalTime()<athlete2.getTotalTime())
			return -1;
		else if(athlete1.getTotalTime()>athlete2.getTotalTime())
		    return 1;
		else
		return 0;
	}

}
