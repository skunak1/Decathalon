package com.sprinter.competition;

import java.io.*;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.bind.util.JAXBSource;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.stream.StreamResult;
import javax.xml.transform.stream.StreamSource;

/* Calculator is the Main class
   1)It reads input from user
   2)Based on input file; it  calculates total timings and populates Athlete Record
   3)It calls method on AthleteRecord class to set Positions
   4)It generates .XML file
   5)It generates .html file on the basis of .XSL file

   LOGIC AND PROGRAM FLOW OUTLINE:
   Step1: Take the csv input file along with location from user
   Step2: Parse the input file and split it on basis of (;)
   Step3: Create Athlete objects and calculate total timings for each athlete
   Step4: Collect Athlete data  in AthleteRecord class
   Step5: Sort the Athlete data on basis of timings using SortAthlete class
   Step6: Invoke method setPosition in AthleteRecord class to populate Positions ( i.e to handle cases of ties and same timings)
   Step7: Generate XML file on the basis of output file name received from user
   Step8: Generate HTML aon basis of default XSL file


   **Assumption: The Class assumes that Athlete timings are decimal based and units are separated by (.)
   * for eg If Kurt timings are 1.2;4.5;6.7.8;6
   * Then his total timings in Net smallest unit would be (1*100+2)+(4*100+5)+(6*100*100+7*100+8)+(6)
   * ie for every(.) encountered in timings the respective digit is multiplied by 100
   * This assumption is implemented in getRecord() method
 */
public class Calculator {

    //Method:For Populating and sorting Athlete records

    public static AthleteRecord getRecord(String recordFile) {
        AthleteRecord allRecord = null;
        ArrayList<Athlete> list = new ArrayList<>();
        try {
            Scanner sc = new Scanner(new File(recordFile)); //To read input file
            allRecord = new AthleteRecord();
            while (sc.hasNext()) {
                Athlete athlete = new Athlete();
                StringBuffer playerTimings = new StringBuffer("");
                String str = sc.nextLine();
                String [] strarray= str.split(";"); // Split the string on basis of ';'
                athlete.setAthleteName(strarray[0]);
                double totaltime=0.0;
                
                for(int i =1;i<strarray.length;i++) {
                        
                    playerTimings.append(strarray[i]);
                    System.out.println(strarray[i]);
                    String [] timebisector = strarray[i].split("\\."); //Split the individual time on basis of '.'
                    
                    System.out.println(timebisector.length);
                    for(int j= 0 ;j<timebisector.length;j++) {
                    	System.out.println(timebisector[j]);
                    	totaltime= totaltime+(Double.parseDouble(timebisector[j]))*Math.pow(100, timebisector.length-(j+1));
                    }
                    if(i<strarray.length-1)
                        playerTimings.append(";");
                }
                athlete.setTimimgs(playerTimings.toString());
                athlete.setTotalTime(totaltime);
                 list.add(athlete);
                
            }
            sc.close();
        } catch (IOException e) {
            System.out.print("ERROR: FILE DOES NOT EXIST OR INPUT NOT CORRECT- TERMINATING THE PROGRAM -->CHECK ERROR LOG =" +e);
            return null;
        }
        allRecord.setAthleteList(list);
        Collections.sort(allRecord.getAthleteList(),new SortAthlete());
     return allRecord;
    }
    public static void main(String args[]) throws Exception{
        Scanner userInput = new Scanner(System.in);
        System.out.println("****************USER - INPUT FORM*************");
        System.out.println("ENTER THE NAME OF CSV INPUT FILE ALONG WITH PATH");
        String inputFile= userInput.next();
        Path inPath = Paths.get(inputFile);
        System.out.println("ENTER THE NAME OF OUTPUT XML FILE TO BE GENERATED");
        String outputFile= userInput.next();
        Path outPath = Paths.get(outputFile);
        userInput.close();

        AthleteRecord record = getRecord(inPath.toString());
        record.setPosition();
       int flag = XMLandHTMLGenerator(record,inPath,outPath);
       if(flag==1)
           System.out.println("******SUCCESSFULLY GENERATED XML AND HTML FILE: "+outPath.toString());
       else
           System.out.println("######THERE HAS BEEN AN ERROR: OPERATION FAILED##############");

    }
//Method: To generate XML and HTML file
    public static int XMLandHTMLGenerator(AthleteRecord record, Path inPath, Path outPath) {

        try {
            TransformerFactory factory = TransformerFactory.newInstance();

            InputStream resourceAsStream = Calculator.class.getResourceAsStream("test.xsl"); //Default XSL file
            //InputStream resourceAsStream = AthleteRecord.class.getResourceAsStream(record.getClass().getResource("test.xsl").toString());
            StreamSource xslt = new StreamSource(resourceAsStream);
            Transformer transformer = factory.newTransformer(xslt);


            JAXBContext contextObj = JAXBContext.newInstance(AthleteRecord.class);
            JAXBSource source = new JAXBSource(contextObj, record);
            StreamResult result = new StreamResult(outPath.toString() + ".htm");
            transformer.transform(source, result);
            Marshaller marshallerObj = contextObj.createMarshaller();
            marshallerObj.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);
            marshallerObj.marshal(record, new FileOutputStream(outPath.toString() + ".xml"));

        } catch (TransformerConfigurationException e) {
                 System.out.println("Caught Exception: "+e.toString());
                 return 0;
        } catch (JAXBException e) {
            System.out.println("Caught Exception: "+e.toString());
                 return 0;
        } catch (TransformerException e) {
            System.out.println("Caught Exception: "+e.toString());
                 return 0;
        } catch (FileNotFoundException e) {
            System.out.println("Caught Exception: "+e.toString());
                 return 0;

        }

        return 1;
    }
}
