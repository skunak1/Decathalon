package com.sprinter.competition;

import java.util.*;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

/*AthleteRecord: Class for collecting all Athlete items into one Collection*/
@XmlRootElement(name = "Athletes")
public class AthleteRecord {
	private ArrayList<Athlete> athleteList; //To collect all Athlete info

    public ArrayList<Athlete> getAthleteList() {
        return athleteList;
    }
	@XmlElement(name = "Athlete")
    public void setAthleteList(ArrayList<Athlete> athleteList) {
        this.athleteList = athleteList;
    }



    public String toString(){
        String value="";
        for(Athlete athlete: athleteList){
            value=value+athlete.toString()+"--Rank is :"+athleteList.indexOf(athlete)+"\n";

        }
        return value;
    }
    

   //To generate Position for all Athletes of all athletes
   /*In case of tie, position will be shared i.e If Athlete A and B scores same time and comes second then their
     positions would be 2-3
    */
    public void setPosition() {
    	ListIterator<Athlete> iterator = athleteList.listIterator();
    	while(iterator.hasNext()) {
    		Athlete athlete = iterator.next();
    		athlete.setRank((athleteList.indexOf(athlete)+1+""));
    		athlete.setPosition(athlete.getRank());
    	}
    	
    	
    	HashMap<Double,ArrayList> recorder = new HashMap<Double,ArrayList>();
    	for(int i = 0;i<athleteList.size()-1;i++) {
    		double di =athleteList.get(i).getTotalTime().doubleValue();
    		ArrayList<Integer> listIndex = new ArrayList<Integer>();
    		listIndex.add(i);
    		for(int j=i+1;j<athleteList.size();j++) {
    			double dj= athleteList.get(j).getTotalTime().doubleValue();
    			if(di==dj) {
    				listIndex.add(j);
    				
    			}
    			else {
    				i=j-1;
					break;
				}
    			
    		}
    		
    		recorder.put(new Double(di),listIndex);
    		
    	}
    	Set<Double> setCodes = recorder.keySet();
    	Iterator<Double> setiterator = setCodes.iterator();
    	while (setiterator.hasNext()) {
    		Double individualScore = setiterator.next();
    		StringBuffer str = new StringBuffer();
    		ArrayList<Integer> respectiveIndexes = recorder.get(individualScore);
    		str.append(athleteList.get(respectiveIndexes.get(0)).getRank());
    		
    		for(int i =1; i<respectiveIndexes.size();i++) {
    			str.append("-");
    			str.append(athleteList.get(respectiveIndexes.get(i)).getRank());
    		}
    		
    		for(int i =0; i<respectiveIndexes.size();i++) {
    			athleteList.get(respectiveIndexes.get(i)).setPosition(str.toString());
    		}
    	}
    	
    }
// Overriding Equals method: To be used in Test Case scenarios
	@Override
	public boolean equals(Object o) {
		if (this == o) return true;
		if (o == null || getClass() != o.getClass()) return false;
		System.out.println("In checking eqiuals");
		AthleteRecord that = (AthleteRecord) o;
        ArrayList<Athlete> thisList = this.getAthleteList();
        ArrayList<Athlete> thatList = that.getAthleteList();
		if(thisList.size()!=thatList.size())
			return false;
        ListIterator<Athlete> thisIterator = thisList.listIterator();
		ListIterator<Athlete>  thatIterator = thatList.listIterator();
		while(thisIterator.hasNext()){
         Athlete thisAthlete = thisIterator.next();
         Athlete thatAthlete = thatIterator.next();
         if(!thisAthlete.equals(thatAthlete))
         	return false;
		}

		return true;
	}

	@Override
	public int hashCode() {

		return Objects.hash(getAthleteList());
	}
}
