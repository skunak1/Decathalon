

package com.sprinter.competition;
import java.util.Objects;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

/* ATHLETE CLASS: The class captures Athletes details from Input file*/

@XmlRootElement(name = "Athlete")
public class Athlete {
    private String athleteName;
    private String position;
    private String timimgs;
    private String rank;
    private Double totalTime;

    public Athlete(){}
/* Constructor for populating values: to bes used in Test Case*/
    public Athlete(String athleteName, String timimgs, String position, Double totalTime) {

        this.athleteName = athleteName;
        this.timimgs = timimgs;
        this.position = position;
        this.totalTime = totalTime;
    }
    /* Constructor for populating values: to bes used in Test Case*/
    public Athlete(String athleteName, String timimgs,Double totalTime) {
        this.athleteName = athleteName;
        this.timimgs = timimgs;
        this.totalTime=totalTime;
    }

    @XmlTransient
    public String getRank() {
        return rank;
    }

    public void setRank(String rank) {
        this.rank = rank;
    }


    @XmlElement(name="Position")
	public String getPosition() {
		return position;
	}

	public void setPosition(String position) {
		this.position = position;
	}

    @XmlElement(name="Name")
	public String getAthleteName() {
        return athleteName;
    }

    public void setAthleteName(String athleteName) {
        this.athleteName = athleteName;
    }

    @XmlElement(name="Timings")
    public String getTimimgs() {
        return timimgs;
    }

    public void setTimimgs(String timimgs) {
        this.timimgs = timimgs;
    }

    @XmlElement(name="TotalTime")
    public Double getTotalTime() {
        return totalTime;
    }

    public void setTotalTime(Double totalTime) {
        this.totalTime = totalTime;
    }
    
    public String toString(){
        String name= athleteName;

        return name+"clocks"+timimgs+"total time taken is :"+totalTime+"Position is "+position;
    }

/* Overirding Equals method for comparing two Athletes objects: To be used  in Test scenarios*/
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Athlete athlete = (Athlete) o;
        return Objects.equals(getAthleteName(), athlete.getAthleteName()) &&
                Objects.equals(getTimimgs(), athlete.getTimimgs()) &&
                Objects.equals(getTotalTime(), athlete.getTotalTime());
    }

    @Override
    public int hashCode() {

        return Objects.hash(getAthleteName(), getTimimgs(), getTotalTime());
    }
}
